## FTP server 

### Run server

```bash
sudo python3 src/
```